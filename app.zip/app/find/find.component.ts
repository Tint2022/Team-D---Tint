import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-find',
  templateUrl: './find.component.html',
  styleUrls: ['./find.component.css']
})
export class FindComponent  {
  e: Employee;
  constructor(private service: EmployeeService) { 
    this.e = new Employee();
  }

  findEmployee(id : number){
    this.e =  this.service.findEmployee(id);
  }
}
