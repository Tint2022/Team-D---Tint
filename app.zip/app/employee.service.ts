import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './model/Employee';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  emp: Employee;
  empArr : Employee[] ;
  constructor(private http: HttpClient) { 
    this.emp = new Employee();
    this.empArr = [];
  }

  addEmployee(emp: Employee)  {
    this.http.post("http://localhost:1212/EMS/CreateEmployee", emp).subscribe();
    return "Record Inserted";
  }

  deleteEmployee(id: number){
     this.http.delete("http://localhost:1212/EMS/DeleteEmployee/"+id).subscribe();
    return "Record Deleted";
  }

  updateEmployee(emp: Employee)  {
    this.http.put("http://localhost:1212/EMS/UpdateEmployee", emp).subscribe();
    return "Record Updated";
  }

  findEmployee(id: number){
    this.http.get<Employee>("http://localhost:1212/EMS/Employee/"+id).subscribe(data => this.emp = data);
    return this.emp;  
 }

 findAllEmployee(){
  this.http.get<Employee[]>("http://localhost:1212/EMS/Employees/").subscribe(data => this.empArr = data);
  return this.empArr;  
}
}
