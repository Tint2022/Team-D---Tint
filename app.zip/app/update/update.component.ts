import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent {
  msg : string = "";
  public employee: Employee;
  constructor(private service: EmployeeService) {
    this.employee = new Employee();
   }

   updateEmployee(data: any){

    this.employee.id = data.id;
    this.employee.name = data.name;
    this.employee.salary = data.salary;
  
    this.msg = this.service.updateEmployee(this.employee);
   }
  
  }
  
