import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent {
  msg : string = "";
  public employee: Employee;
  constructor(private service: EmployeeService) {
    this.employee = new Employee();
   }

 insertEmployee(data: any){

  this.employee.id = data.id;
  this.employee.name = data.name;
  this.employee.salary = data.salary;

  this.msg = this.service.addEmployee(this.employee);
 }

}

