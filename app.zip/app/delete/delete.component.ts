import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent  {
  msg: string = "";
  constructor(private service: EmployeeService) { }

  deleteEmployee(id : number){
    this.msg = this.service.deleteEmployee(id);
  }

}
