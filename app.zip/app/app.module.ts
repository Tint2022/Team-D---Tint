import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';  

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeService } from './employee.service';
import { EmployeeComponent } from './employee/employee.component';
import { Routes, RouterModule } from '@angular/router';
import { InsertComponent } from './insert/insert.component';
import { DeleteComponent } from './delete/delete.component';
import { UpdateComponent } from './update/update.component';
import { FindComponent } from './find/find.component';
import { FindAllComponent } from './find-all/find-all.component';
const ROUTES: Routes = [
  { path : 'Insert', component : InsertComponent},
  { path : 'Delete', component : DeleteComponent},
  { path : 'Update', component : UpdateComponent},
  { path : 'Find', component : FindComponent},
  { path : 'FindAll', component : FindAllComponent}
  ];
  
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    InsertComponent,
    DeleteComponent,
    UpdateComponent,
    FindComponent,
    FindAllComponent
  ],
  imports: [
    RouterModule.forRoot(ROUTES),
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [
    EmployeeService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
