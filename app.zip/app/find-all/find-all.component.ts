import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../model/Employee';

@Component({
  selector: 'app-find-all',
  templateUrl: './find-all.component.html',
  styleUrls: ['./find-all.component.css']
})
export class FindAllComponent {
  empArr: Employee[];
  constructor(private service: EmployeeService) { 
    this.empArr = this.service.findAllEmployee();
    
  }


}
